//! Known Answer Tests (KATs) for SPHINCS+ Rust implementation.

use sphincsplus_rs::{SphincsPlus, ParameterSet, PublicKey, SecretKey, Signature};
use std::fs::File;
use std::io::{BufRead, BufReader};

fn hex_to_bytes(s: &str) -> Vec<u8> {
    let s = s.trim();
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).unwrap())
        .collect()
}

#[test]
fn kat_verify_vectors() {
    let kat_file = "tests/PQCsignKAT_64.rsp";
    let file = File::open(kat_file).expect("KAT file missing");
    let reader = BufReader::new(file);

    let mut count = 0;
    let mut seed = Vec::new();
    let mut m = Vec::new();
    let mut pk = Vec::new();
    let mut sk = Vec::new();
    let mut sm = Vec::new();

    for line in reader.lines().map(|l| l.unwrap()) {
        let line = line.trim();
        if line.starts_with("count = ") {
            count = line[8..].parse::<usize>().unwrap();
        } else if line.starts_with("seed = ") {
            seed = hex_to_bytes(&line[7..]);
        } else if line.starts_with("mlen = ") {
        } else if line.starts_with("msg = ") {
            m = hex_to_bytes(&line[6..]);
        } else if line.starts_with("pk = ") {
            pk = hex_to_bytes(&line[5..]);
        } else if line.starts_with("sk = ") {
            sk = hex_to_bytes(&line[5..]);
        } else if line.starts_with("smlen = ") {
        } else if line.starts_with("sm = ") {
            sm = hex_to_bytes(&line[5..]);
            let parameter_set = ParameterSet::Shake128f;
            let public_key = PublicKey { parameter_set, bytes: pk.clone() };
            let secret_key = SecretKey { parameter_set, bytes: sk.clone().into() };
            let sig_len = parameter_set.params().bytes;
            let signature = Signature { parameter_set, bytes: sm[..sig_len].to_vec() };
            let msg = sm[sig_len..].to_vec();
            assert!(SphincsPlus::verify(&msg, &signature, &public_key).unwrap(), "KAT vector {} failed", count);
        }
    }
}
