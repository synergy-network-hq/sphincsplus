//! Winternitz One-Time Signature (WOTS+) scheme.

use crate::address::Address;
use crate::context::SphincsContext;
use crate::thash::thash_wots;
use crate::utils::{base_w, xor_bytes};
use alloc::vec::Vec;
use alloc::vec;

/// Computes a WOTS+ public key from a WOTS+ signature and a message.
/// This corresponds to `wots_pk_from_sig` in the C reference.
pub fn wots_pk_from_sig(
    pk: &mut [u8],
    sig: &[u8],
    msg: &[u8],
    ctx: &SphincsContext,
    addr: &Address,
) {
    let params = &ctx.params;
    let n = params.n;
    let w = params.wots_w as u32;
    let wots_len = params.wots_len;
    
    assert_eq!(pk.len(), params.wots_pk_bytes);
    assert_eq!(sig.len(), params.wots_bytes);
    assert_eq!(msg.len(), n);

    let mut lengths = vec![0u32; wots_len];
    chain_lengths(&mut lengths, msg, w, params.wots_len1, params.wots_len2);

    for i in 0..wots_len {
        let mut current_addr = addr.clone();
        current_addr.set_chain(i as u32);

        let mut chain_val = Vec::from(&sig[i * n..(i + 1) * n]);
        for _ in 0..lengths[i] {
            thash_wots(&mut chain_val, &chain_val, ctx, &current_addr);
            current_addr.set_hash(current_addr.hash() + 1);
        }
        pk[i * n..(i + 1) * n].copy_from_slice(&chain_val);
    }
}

/// Computes the chain lengths for a given message hash.
/// This corresponds to `chain_lengths` in the C reference.
pub fn chain_lengths(
    lengths: &mut [u32],
    msg: &[u8],
    w: u32,
    len_1: usize,
    len_2: usize,
) {
    let mut msg_base_w = vec![0u32; len_1];
    base_w(&mut msg_base_w, msg, w, len_1);

    let mut csum_base_w = vec![0u32; len_2];
    let mut csum = 0u32;
    for i in 0..len_1 {
        csum += w - 1 - msg_base_w[i];
    }

    let mut tmp_csum = csum;
    for i in 0..len_2 {
        csum_base_w[i] = tmp_csum % w;
        tmp_csum /= w;
    }

    for i in 0..len_1 {
        lengths[i] = msg_base_w[i];
    }
    for i in 0..len_2 {
        lengths[len_1 + i] = csum_base_w[i];
    }
}

/// Generates a WOTS+ signature.
/// This corresponds to `wots_sign` in the C reference.
pub fn wots_sign(
    sig: &mut [u8],
    msg: &[u8],
    sk_seed: &[u8],
    ctx: &SphincsContext,
    addr: &Address,
) {
    let params = &ctx.params;
    let n = params.n;
    let w = params.wots_w as u32;
    let wots_len = params.wots_len;

    assert_eq!(sig.len(), params.wots_bytes);
    assert_eq!(msg.len(), n);
    assert_eq!(sk_seed.len(), n);

    let mut lengths = vec![0u32; wots_len];
    chain_lengths(&mut lengths, msg, w, params.wots_len1, params.wots_len2);

    for i in 0..wots_len {
        let mut current_addr = addr.clone();
        current_addr.set_chain(i as u32);

        let mut sk_addr = current_addr.clone();
        sk_addr.set_type(crate::address::addr_type::WOTS);
        sk_addr.set_keypair(addr.keypair());

        let mut sk_val = vec![0u8; n];
        crate::hash::prf_addr(&mut sk_val, sk_seed, &sk_addr, ctx);

        let mut chain_val = sk_val;
        for _ in 0..lengths[i] {
            thash_wots(&mut chain_val, &chain_val, ctx, &current_addr);
            current_addr.set_hash(current_addr.hash() + 1);
        }
        sig[i * n..(i + 1) * n].copy_from_slice(&chain_val);
    }
}

/// Computes a WOTS+ public key from a WOTS+ secret key.
/// This corresponds to `wots_pk_gen` in the C reference.
pub fn wots_pk_gen(
    pk: &mut [u8],
    sk_seed: &[u8],
    ctx: &SphincsContext,
    addr: &Address,
) {
    let params = &ctx.params;
    let n = params.n;
    let w = params.wots_w as u32;
    let wots_len = params.wots_len;

    assert_eq!(pk.len(), params.wots_pk_bytes);
    assert_eq!(sk_seed.len(), n);

    for i in 0..wots_len {
        let mut current_addr = addr.clone();
        current_addr.set_chain(i as u32);

        let mut sk_addr = current_addr.clone();
        sk_addr.set_type(crate::address::addr_type::WOTS);
        sk_addr.set_keypair(addr.keypair());

        let mut sk_val = vec![0u8; n];
        crate::hash::prf_addr(&mut sk_val, sk_seed, &sk_addr, ctx);

        let mut chain_val = sk_val;
        for _ in 0..(w - 1) {
            thash_wots(&mut chain_val, &chain_val, ctx, &current_addr);
            current_addr.set_hash(current_addr.hash() + 1);
        }
        pk[i * n..(i + 1) * n].copy_from_slice(&chain_val);
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params::ParameterSet;
    use crate::address::addr_type;

    #[test]
    fn test_chain_lengths() {
        let parameter_set = ParameterSet::Shake128f;
        let params = parameter_set.params();
        let msg = vec![0x01; params.n];
        let mut lengths = vec![0u32; params.wots_len];
        
        chain_lengths(&mut lengths, &msg, params.wots_w as u32, params.wots_len1, params.wots_len2);
        
        // For Shake128f, w=16, len1=32, len2=2
        // msg_base_w will be all 1s (0x01 = 00000001, base-16 is 0, 0, ..., 1)
        // This test case needs to be more robust with actual values from C reference
        // For now, just check if lengths are within expected range
        for l in &lengths {
            assert!(*l < params.wots_w as u32);
        }
    }

    #[test]
    fn test_wots_sign_and_pk_from_sig() {
        let parameter_set = ParameterSet::Shake128f;
        let params = parameter_set.params();
        let mut ctx = SphincsContext::new_for_signing(parameter_set, &vec![0u8; params.n], &vec![1u8; params.n]);
        
        let msg = vec![0x05; params.n];
        let sk_seed = vec![0x06; params.n];
        let mut addr = Address::new();
        addr.setup_wots(0, 0, 0);

        let mut sig = vec![0u8; params.wots_bytes];
        wots_sign(&mut sig, &msg, &sk_seed, &ctx, &addr);

        let mut pk_from_sig = vec![0u8; params.wots_pk_bytes];
        wots_pk_from_sig(&mut pk_from_sig, &sig, &msg, &ctx, &addr);

        let mut pk_gen = vec![0u8; params.wots_pk_bytes];
        wots_pk_gen(&mut pk_gen, &sk_seed, &ctx, &addr);

        // The public key derived from the signature should match the one generated directly
        assert_eq!(pk_from_sig, pk_gen);
    }
}

