//! SPHINCS+ context structure for holding state during operations.

use crate::params::{ParameterSet, SphincsParams};
use alloc::vec::Vec;
use zeroize::{Zeroize, ZeroizeOnDrop};

/// SPHINCS+ context structure that holds the state during cryptographic operations.
/// This corresponds to the `spx_ctx` structure in the C reference implementation.
#[derive(Clone, Debug)]
pub struct SphincsContext {
    /// The parameter set being used
    pub parameter_set: ParameterSet,
    /// The parameters for this context
    pub params: SphincsParams,
    /// Public seed (PUB_SEED)
    pub pub_seed: Vec<u8>,
    /// Secret seed (SK_SEED) - only present during signing
    pub sk_seed: Option<zeroize::Zeroizing<Vec<u8>>>,
    /// Hash function state (implementation-specific)
    pub hash_state: HashState,
}

/// Hash function state for different hash types.
#[derive(Clone, Debug)]
pub enum HashState {
    /// SHAKE-based hash state
    Shake {
        /// Precomputed state for SHAKE operations
        state: Vec<u8>,
    },
    /// SHA2-based hash state
    Sha2 {
        /// Precomputed state for SHA2 operations
        state: Vec<u8>,
    },
}

impl Zeroize for HashState {
    fn zeroize(&mut self) {
        match self {
            HashState::Shake { state } => state.zeroize(),
            HashState::Sha2 { state } => state.zeroize(),
        }
    }
}

impl SphincsContext {
    /// Create a new SPHINCS+ context for verification (public operations only).
    pub fn new_for_verification(parameter_set: ParameterSet, pub_seed: &[u8]) -> Self {
        let params = parameter_set.params();
        
        // Validate pub_seed length
        assert_eq!(pub_seed.len(), params.n);
        
        let hash_state = match parameter_set.hash_type() {
            crate::params::HashType::Shake => HashState::Shake {
                state: Vec::new(), // Will be initialized by hash function
            },
            crate::params::HashType::Sha2 => HashState::Sha2 {
                state: Vec::new(), // Will be initialized by hash function
            },
        };

        Self {
            parameter_set,
            params,
            pub_seed: pub_seed.to_vec(),
            sk_seed: None,
            hash_state,
        }
    }

    /// Create a new SPHINCS+ context for signing (includes secret seed).
    pub fn new_for_signing(
        parameter_set: ParameterSet,
        pub_seed: &[u8],
        sk_seed: &[u8],
    ) -> Self {
        let params = parameter_set.params();
        
        // Validate seed lengths
        assert_eq!(pub_seed.len(), params.n);
        assert_eq!(sk_seed.len(), params.n);
        
        let hash_state = match parameter_set.hash_type() {
            crate::params::HashType::Shake => HashState::Shake {
                state: Vec::new(), // Will be initialized by hash function
            },
            crate::params::HashType::Sha2 => HashState::Sha2 {
                state: Vec::new(), // Will be initialized by hash function
            },
        };

        Self {
            parameter_set,
            params,
            pub_seed: pub_seed.to_vec(),
            sk_seed: Some(zeroize::Zeroizing::new(sk_seed.to_vec())),
            hash_state,
        }
    }

    /// Get the hash output length for this context.
    pub fn n(&self) -> usize {
        self.params.n
    }

    /// Get the address length for this context.
    pub fn addr_bytes(&self) -> usize {
        self.params.addr_bytes
    }

    /// Check if this context can be used for signing operations.
    pub fn can_sign(&self) -> bool {
        self.sk_seed.is_some()
    }

    /// Get the secret seed (only available for signing contexts).
    pub fn sk_seed(&self) -> Option<&[u8]> {
        self.sk_seed.as_ref().map(|s| s.as_slice())
    }

    /// Get the public seed.
    pub fn pub_seed(&self) -> &[u8] {
        &self.pub_seed
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params::ParameterSet;

    #[test]
    fn test_context_creation() {
        let parameter_set = ParameterSet::Shake128f;
        let params = parameter_set.params();
        
        let pub_seed = vec![0u8; params.n];
        let sk_seed = vec![1u8; params.n];

        // Test verification context
        let ctx_verify = SphincsContext::new_for_verification(parameter_set, &pub_seed);
        assert_eq!(ctx_verify.parameter_set, parameter_set);
        assert_eq!(ctx_verify.pub_seed(), &pub_seed);
        assert!(!ctx_verify.can_sign());
        assert!(ctx_verify.sk_seed().is_none());

        // Test signing context
        let ctx_sign = SphincsContext::new_for_signing(parameter_set, &pub_seed, &sk_seed);
        assert_eq!(ctx_sign.parameter_set, parameter_set);
        assert_eq!(ctx_sign.pub_seed(), &pub_seed);
        assert!(ctx_sign.can_sign());
        assert_eq!(ctx_sign.sk_seed().unwrap(), &sk_seed);
    }

    #[test]
    fn test_context_parameters() {
        let parameter_set = ParameterSet::Shake256f;
        let params = parameter_set.params();
        
        let pub_seed = vec![0u8; params.n];
        let ctx = SphincsContext::new_for_verification(parameter_set, &pub_seed);

        assert_eq!(ctx.n(), params.n);
        assert_eq!(ctx.addr_bytes(), params.addr_bytes);
    }
}

