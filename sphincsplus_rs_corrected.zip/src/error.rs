//! Error types for SPHINCS+ operations.

use core::fmt;

/// Result type for SPHINCS+ operations.
pub type Result<T> = core::result::Result<T, Error>;

/// Errors that can occur during SPHINCS+ operations.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Error {
    /// Invalid parameter set
    InvalidParameterSet,
    /// Invalid key length
    InvalidKeyLength,
    /// Invalid signature length
    InvalidSignatureLength,
    /// Invalid seed length
    InvalidSeedLength,
    /// Signature verification failed
    VerificationFailed,
    /// Invalid input data
    InvalidInput,
    /// Internal error
    Internal(&'static str),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::InvalidParameterSet => write!(f, "Invalid parameter set"),
            Error::InvalidKeyLength => write!(f, "Invalid key length"),
            Error::InvalidSignatureLength => write!(f, "Invalid signature length"),
            Error::InvalidSeedLength => write!(f, "Invalid seed length"),
            Error::VerificationFailed => write!(f, "Signature verification failed"),
            Error::InvalidInput => write!(f, "Invalid input data"),
            Error::Internal(msg) => write!(f, "Internal error: {}", msg),
        }
    }
}

#[cfg(feature = "std")]
impl std::error::Error for Error {}

