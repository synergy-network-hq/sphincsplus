//! SPHINCS+ address handling.
//!
//! This module implements the address structure used throughout SPHINCS+
//! to identify different parts of the signature scheme.

use alloc::vec::Vec;

/// SPHINCS+ address type constants.
pub mod addr_type {
    /// WOTS hash address type
    pub const WOTS: u32 = 0;
    /// WOTS public key address type
    pub const WOTS_PK: u32 = 1;
    /// Hash tree address type
    pub const HASH_TREE: u32 = 2;
    /// FORS tree address type
    pub const FORS_TREE: u32 = 3;
    /// FORS public key address type
    pub const FORS_PK: u32 = 4;
}

/// SPHINCS+ address structure.
/// 
/// The address is a 32-byte structure that encodes the location
/// within the SPHINCS+ signature scheme hierarchy.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Address {
    /// Raw address bytes (32 bytes)
    pub bytes: [u32; 8],
}

impl Address {
    /// Create a new address initialized to zero.
    pub fn new() -> Self {
        Self { bytes: [0; 8] }
    }

    /// Create an address from raw bytes.
    pub fn from_bytes(bytes: [u32; 8]) -> Self {
        Self { bytes }
    }

    /// Get the raw bytes of the address.
    pub fn as_bytes(&self) -> &[u32; 8] {
        &self.bytes
    }

    /// Convert the address to a byte array (big-endian).
    pub fn to_byte_array(&self) -> [u8; 32] {
        let mut result = [0u8; 32];
        for (i, &word) in self.bytes.iter().enumerate() {
            let bytes = word.to_be_bytes();
            result[i * 4..(i + 1) * 4].copy_from_slice(&bytes);
        }
        result
    }

    /// Create an address from a byte array (big-endian).
    pub fn from_byte_array(bytes: &[u8; 32]) -> Self {
        let mut words = [0u32; 8];
        for i in 0..8 {
            words[i] = u32::from_be_bytes([
                bytes[i * 4],
                bytes[i * 4 + 1],
                bytes[i * 4 + 2],
                bytes[i * 4 + 3],
            ]);
        }
        Self { bytes: words }
    }

    /// Set the layer address.
    pub fn set_layer(&mut self, layer: u32) {
        self.bytes[0] = layer;
    }

    /// Get the layer address.
    pub fn layer(&self) -> u32 {
        self.bytes[0]
    }

    /// Set the tree address.
    pub fn set_tree(&mut self, tree: u64) {
        self.bytes[1] = (tree >> 32) as u32;
        self.bytes[2] = tree as u32;
    }

    /// Get the tree address.
    pub fn tree(&self) -> u64 {
        ((self.bytes[1] as u64) << 32) | (self.bytes[2] as u64)
    }

    /// Set the type address.
    pub fn set_type(&mut self, addr_type: u32) {
        self.bytes[3] = addr_type;
    }

    /// Get the type address.
    pub fn addr_type(&self) -> u32 {
        self.bytes[3]
    }

    /// Set the keypair address.
    pub fn set_keypair(&mut self, keypair: u32) {
        self.bytes[5] = keypair;
    }

    /// Get the keypair address.
    pub fn keypair(&self) -> u32 {
        self.bytes[5]
    }

    /// Set the chain address.
    pub fn set_chain(&mut self, chain: u32) {
        self.bytes[6] = chain;
    }

    /// Get the chain address.
    pub fn chain(&self) -> u32 {
        self.bytes[6]
    }

    /// Set the hash address.
    pub fn set_hash(&mut self, hash: u32) {
        self.bytes[7] = hash;
    }

    /// Get the hash address.
    pub fn hash(&self) -> u32 {
        self.bytes[7]
    }

    /// Set the tree height.
    pub fn set_tree_height(&mut self, height: u32) {
        self.bytes[6] = height;
    }

    /// Get the tree height.
    pub fn tree_height(&self) -> u32 {
        self.bytes[6]
    }

    /// Set the tree index.
    pub fn set_tree_index(&mut self, index: u32) {
        self.bytes[7] = index;
    }

    /// Get the tree index.
    pub fn tree_index(&self) -> u32 {
        self.bytes[7]
    }

    /// Copy the subtree address from another address.
    pub fn copy_subtree_from(&mut self, other: &Address) {
        self.bytes[0] = other.bytes[0]; // layer
        self.bytes[1] = other.bytes[1]; // tree (high)
        self.bytes[2] = other.bytes[2]; // tree (low)
    }

    /// Copy the keypair address from another address.
    pub fn copy_keypair_from(&mut self, other: &Address) {
        self.copy_subtree_from(other);
        self.bytes[5] = other.bytes[5]; // keypair
    }
}

impl Default for Address {
    fn default() -> Self {
        Self::new()
    }
}

/// Helper functions for address manipulation (matching C reference implementation).
impl Address {
    /// Set up a WOTS address.
    pub fn setup_wots(&mut self, layer: u32, tree: u64, keypair: u32) {
        self.set_layer(layer);
        self.set_tree(tree);
        self.set_type(addr_type::WOTS);
        self.set_keypair(keypair);
    }

    /// Set up a WOTS public key address.
    pub fn setup_wots_pk(&mut self, layer: u32, tree: u64, keypair: u32) {
        self.set_layer(layer);
        self.set_tree(tree);
        self.set_type(addr_type::WOTS_PK);
        self.set_keypair(keypair);
    }

    /// Set up a hash tree address.
    pub fn setup_hash_tree(&mut self, layer: u32, tree: u64) {
        self.set_layer(layer);
        self.set_tree(tree);
        self.set_type(addr_type::HASH_TREE);
    }

    /// Set up a FORS tree address.
    pub fn setup_fors_tree(&mut self, keypair: u32) {
        self.set_layer(0);
        self.set_tree(0);
        self.set_type(addr_type::FORS_TREE);
        self.set_keypair(keypair);
    }

    /// Set up a FORS public key address.
    pub fn setup_fors_pk(&mut self, keypair: u32) {
        self.set_layer(0);
        self.set_tree(0);
        self.set_type(addr_type::FORS_PK);
        self.set_keypair(keypair);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_address_creation() {
        let addr = Address::new();
        assert_eq!(addr.bytes, [0; 8]);

        let addr = Address::from_bytes([1, 2, 3, 4, 5, 6, 7, 8]);
        assert_eq!(addr.bytes, [1, 2, 3, 4, 5, 6, 7, 8]);
    }

    #[test]
    fn test_address_byte_conversion() {
        let addr = Address::from_bytes([0x12345678, 0x9abcdef0, 0, 0, 0, 0, 0, 0]);
        let byte_array = addr.to_byte_array();
        
        // Check big-endian conversion
        assert_eq!(byte_array[0..4], [0x12, 0x34, 0x56, 0x78]);
        assert_eq!(byte_array[4..8], [0x9a, 0xbc, 0xde, 0xf0]);
        
        // Test round-trip conversion
        let addr2 = Address::from_byte_array(&byte_array);
        assert_eq!(addr, addr2);
    }

    #[test]
    fn test_address_fields() {
        let mut addr = Address::new();
        
        addr.set_layer(42);
        assert_eq!(addr.layer(), 42);
        
        addr.set_tree(0x123456789abcdef0);
        assert_eq!(addr.tree(), 0x123456789abcdef0);
        
        addr.set_type(addr_type::WOTS);
        assert_eq!(addr.addr_type(), addr_type::WOTS);
        
        addr.set_keypair(100);
        assert_eq!(addr.keypair(), 100);
        
        addr.set_chain(200);
        assert_eq!(addr.chain(), 200);
        
        addr.set_hash(300);
        assert_eq!(addr.hash(), 300);
    }

    #[test]
    fn test_address_setup() {
        let mut addr = Address::new();
        
        addr.setup_wots(1, 0x123456789abcdef0, 42);
        assert_eq!(addr.layer(), 1);
        assert_eq!(addr.tree(), 0x123456789abcdef0);
        assert_eq!(addr.addr_type(), addr_type::WOTS);
        assert_eq!(addr.keypair(), 42);
        
        addr.setup_fors_tree(100);
        assert_eq!(addr.layer(), 0);
        assert_eq!(addr.tree(), 0);
        assert_eq!(addr.addr_type(), addr_type::FORS_TREE);
        assert_eq!(addr.keypair(), 100);
    }

    #[test]
    fn test_address_copy() {
        let mut addr1 = Address::new();
        addr1.setup_wots(5, 0x1234567890abcdef, 99);
        
        let mut addr2 = Address::new();
        addr2.copy_subtree_from(&addr1);
        
        assert_eq!(addr2.layer(), 5);
        assert_eq!(addr2.tree(), 0x1234567890abcdef);
        assert_eq!(addr2.addr_type(), 0); // Not copied
        assert_eq!(addr2.keypair(), 0); // Not copied
        
        addr2.copy_keypair_from(&addr1);
        assert_eq!(addr2.keypair(), 99);
    }
}

