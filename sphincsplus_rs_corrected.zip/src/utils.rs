//! Utility functions for SPHINCS+.

use alloc::vec::Vec;
use subtle::{Choice, ConditionallySelectable, ConstantTimeEq};

/// Convert a byte slice to a base-w representation.
/// This corresponds to `base_w` in the C reference.
pub fn base_w(output: &mut [u32], input: &[u8], w: u32, out_len: usize) {
    let in_len = input.len();
    let mut bits = 0u32;
    let mut total = 0usize;
    let log_w = match w {
        16 => 4,
        256 => 8,
        _ => panic!("Unsupported Winternitz parameter w"),
    };

    for i in 0..in_len {
        bits += 8;
        total += input[i] as u32;
        total <<= 8;

        while bits >= log_w && i < out_len {
            bits -= log_w;
            output[i] = ((total >> bits) & ((1 << log_w) - 1)) as u32;
        }
    }
}

/// XOR two byte arrays in-place.
/// This corresponds to array XOR operations in the C reference.
pub fn xor_bytes(a: &mut [u8], b: &[u8]) {
    for (dst, src) in a.iter_mut().zip(b.iter()) {
        *dst ^= *src;
    }
}

/// Convert a byte array to a u32 value (big-endian).
/// This corresponds to `bytes_to_ull` for 32-bit values in the C reference.
pub fn bytes_to_u32(bytes: &[u8]) -> u32 {
    let mut result = 0u32;
    for (i, &byte) in bytes.iter().enumerate().take(4) {
        result |= (byte as u32) << (8 * (3 - i));
    }
    result
}

/// Convert a u32 value to a byte array (big-endian).
/// This corresponds to `ull_to_bytes` for 32-bit values in the C reference.
pub fn u32_to_bytes(value: u32) -> [u8; 4] {
    [
        (value >> 24) as u8,
        (value >> 16) as u8,
        (value >> 8) as u8,
        value as u8,
    ]
}

/// Compute a checksum for WOTS+ chains.
/// This corresponds to `checksum` in the C reference.
pub fn wots_checksum(msg: &[u32], msg_len: usize, w: u32) -> u32 {
    let mut checksum = 0u32;
    for &val in msg.iter().take(msg_len) {
        checksum += w - 1 - val;
    }
    checksum <<= (8 - ((msg_len * w.trailing_zeros() as usize) % 8)) % 8;
    checksum
}

/// Convert bytes to u64 (big-endian).
pub fn bytes_to_u64(bytes: &[u8]) -> u64 {
    let mut result = 0u64;
    for (i, &byte) in bytes.iter().enumerate().take(8) {
        result |= (byte as u64) << (8 * (7 - i));
    }
    result
}

/// Convert u64 to bytes (big-endian).
pub fn u64_to_bytes(value: u64) -> [u8; 8] {
    [
        (value >> 56) as u8,
        (value >> 48) as u8,
        (value >> 40) as u8,
        (value >> 32) as u8,
        (value >> 24) as u8,
        (value >> 16) as u8,
        (value >> 8) as u8,
        value as u8,
    ]
}

/// Generate random bytes for cryptographic operations.
/// This is a placeholder implementation using zeros for now.
/// In production, this should use a secure random number generator.
pub fn randombytes(out: &mut [u8]) {
    // TODO: Replace with secure RNG like getrandom
    out.fill(0);
}
