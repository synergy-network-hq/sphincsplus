//! SPHINCS+ parameter sets and constants.

use crate::error::{Error, Result};

/// SPHINCS+ parameter sets as defined by NIST.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ParameterSet {
    /// SPHINCS+-SHAKE-128f-simple
    Shake128f,
    /// SPHINCS+-SHAKE-128s-simple
    Shake128s,
    /// SPHINCS+-SHAKE-192f-simple
    Shake192f,
    /// SPHINCS+-SHAKE-192s-simple
    Shake192s,
    /// SPHINCS+-SHAKE-256f-simple
    Shake256f,
    /// SPHINCS+-SHAKE-256s-simple
    Shake256s,
    /// SPHINCS+-SHA2-128f-simple
    Sha2_128f,
    /// SPHINCS+-SHA2-128s-simple
    Sha2_128s,
    /// SPHINCS+-SHA2-192f-simple
    Sha2_192f,
    /// SPHINCS+-SHA2-192s-simple
    Sha2_192s,
    /// SPHINCS+-SHA2-256f-simple
    Sha2_256f,
    /// SPHINCS+-SHA2-256s-simple
    Sha2_256s,
}

/// SPHINCS+ parameters for a specific parameter set.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct SphincsParams {
    /// Hash output length in bytes
    pub n: usize,
    /// Height of the hypertree
    pub full_height: usize,
    /// Number of subtree layers
    pub d: usize,
    /// FORS tree dimensions
    pub fors_height: usize,
    /// Number of FORS trees
    pub fors_trees: usize,
    /// Winternitz parameter
    pub wots_w: usize,
    /// Address bytes
    pub addr_bytes: usize,
    /// WOTS log w
    pub wots_logw: usize,
    /// WOTS len1
    pub wots_len1: usize,
    /// WOTS len2
    pub wots_len2: usize,
    /// WOTS len
    pub wots_len: usize,
    /// WOTS bytes
    pub wots_bytes: usize,
    /// WOTS public key bytes
    pub wots_pk_bytes: usize,
    /// Subtree height
    pub tree_height: usize,
    /// FORS message bytes
    pub fors_msg_bytes: usize,
    /// FORS bytes
    pub fors_bytes: usize,
    /// FORS public key bytes
    pub fors_pk_bytes: usize,
    /// Total signature bytes
    pub bytes: usize,
    /// Public key bytes
    pub pk_bytes: usize,
    /// Secret key bytes
    pub sk_bytes: usize,
    /// Seed bytes
    pub seed_bytes: usize,
}

impl ParameterSet {
    /// Get the parameters for this parameter set.
    pub fn params(self) -> SphincsParams {
        match self {
            ParameterSet::Shake128f => SphincsParams {
                n: 16,
                full_height: 66,
                d: 22,
                fors_height: 6,
                fors_trees: 33,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 32,
                wots_len2: 2,
                wots_len: 34,
                wots_bytes: 544,
                wots_pk_bytes: 544,
                tree_height: 3,
                fors_msg_bytes: 25,
                fors_bytes: 1848,
                fors_pk_bytes: 16,
                bytes: 17088,
                pk_bytes: 32,
                sk_bytes: 64,
                seed_bytes: 48,
            },
            ParameterSet::Shake128s => SphincsParams {
                n: 16,
                full_height: 63,
                d: 7,
                fors_height: 12,
                fors_trees: 14,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 32,
                wots_len2: 2,
                wots_len: 34,
                wots_bytes: 544,
                wots_pk_bytes: 544,
                tree_height: 9,
                fors_msg_bytes: 21,
                fors_bytes: 2912,
                fors_pk_bytes: 16,
                bytes: 7856,
                pk_bytes: 32,
                sk_bytes: 64,
                seed_bytes: 48,
            },
            ParameterSet::Shake192f => SphincsParams {
                n: 24,
                full_height: 66,
                d: 22,
                fors_height: 8,
                fors_trees: 33,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 48,
                wots_len2: 3,
                wots_len: 51,
                wots_bytes: 1224,
                wots_pk_bytes: 1224,
                tree_height: 3,
                fors_msg_bytes: 33,
                fors_bytes: 7128,
                fors_pk_bytes: 24,
                bytes: 35664,
                pk_bytes: 48,
                sk_bytes: 96,
                seed_bytes: 72,
            },
            ParameterSet::Shake192s => SphincsParams {
                n: 24,
                full_height: 63,
                d: 7,
                fors_height: 14,
                fors_trees: 17,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 48,
                wots_len2: 3,
                wots_len: 51,
                wots_bytes: 1224,
                wots_pk_bytes: 1224,
                tree_height: 9,
                fors_msg_bytes: 30,
                fors_bytes: 9180,
                fors_pk_bytes: 24,
                bytes: 16224,
                pk_bytes: 48,
                sk_bytes: 96,
                seed_bytes: 72,
            },
            ParameterSet::Shake256f => SphincsParams {
                n: 32,
                full_height: 68,
                d: 17,
                fors_height: 9,
                fors_trees: 35,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 64,
                wots_len2: 3,
                wots_len: 67,
                wots_bytes: 2144,
                wots_pk_bytes: 2144,
                tree_height: 4,
                fors_msg_bytes: 40,
                fors_bytes: 11200,
                fors_pk_bytes: 32,
                bytes: 49856,
                pk_bytes: 64,
                sk_bytes: 128,
                seed_bytes: 96,
            },
            ParameterSet::Shake256s => SphincsParams {
                n: 32,
                full_height: 64,
                d: 8,
                fors_height: 14,
                fors_trees: 22,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 64,
                wots_len2: 3,
                wots_len: 67,
                wots_bytes: 2144,
                wots_pk_bytes: 2144,
                tree_height: 8,
                fors_msg_bytes: 39,
                fors_bytes: 10560,
                fors_pk_bytes: 32,
                bytes: 29792,
                pk_bytes: 64,
                sk_bytes: 128,
                seed_bytes: 96,
            },
            ParameterSet::Sha2_128f => SphincsParams {
                n: 16,
                full_height: 66,
                d: 22,
                fors_height: 6,
                fors_trees: 33,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 32,
                wots_len2: 2,
                wots_len: 34,
                wots_bytes: 544,
                wots_pk_bytes: 544,
                tree_height: 3,
                fors_msg_bytes: 25,
                fors_bytes: 1848,
                fors_pk_bytes: 16,
                bytes: 17088,
                pk_bytes: 32,
                sk_bytes: 64,
                seed_bytes: 48,
            },
            ParameterSet::Sha2_128s => SphincsParams {
                n: 16,
                full_height: 63,
                d: 7,
                fors_height: 12,
                fors_trees: 14,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 32,
                wots_len2: 2,
                wots_len: 34,
                wots_bytes: 544,
                wots_pk_bytes: 544,
                tree_height: 9,
                fors_msg_bytes: 21,
                fors_bytes: 2912,
                fors_pk_bytes: 16,
                bytes: 7856,
                pk_bytes: 32,
                sk_bytes: 64,
                seed_bytes: 48,
            },
            ParameterSet::Sha2_192f => SphincsParams {
                n: 24,
                full_height: 66,
                d: 22,
                fors_height: 8,
                fors_trees: 33,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 48,
                wots_len2: 3,
                wots_len: 51,
                wots_bytes: 1224,
                wots_pk_bytes: 1224,
                tree_height: 3,
                fors_msg_bytes: 33,
                fors_bytes: 7128,
                fors_pk_bytes: 24,
                bytes: 35664,
                pk_bytes: 48,
                sk_bytes: 96,
                seed_bytes: 72,
            },
            ParameterSet::Sha2_192s => SphincsParams {
                n: 24,
                full_height: 63,
                d: 7,
                fors_height: 14,
                fors_trees: 17,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 48,
                wots_len2: 3,
                wots_len: 51,
                wots_bytes: 1224,
                wots_pk_bytes: 1224,
                tree_height: 9,
                fors_msg_bytes: 30,
                fors_bytes: 9180,
                fors_pk_bytes: 24,
                bytes: 16224,
                pk_bytes: 48,
                sk_bytes: 96,
                seed_bytes: 72,
            },
            ParameterSet::Sha2_256f => SphincsParams {
                n: 32,
                full_height: 68,
                d: 17,
                fors_height: 9,
                fors_trees: 35,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 64,
                wots_len2: 3,
                wots_len: 67,
                wots_bytes: 2144,
                wots_pk_bytes: 2144,
                tree_height: 4,
                fors_msg_bytes: 40,
                fors_bytes: 11200,
                fors_pk_bytes: 32,
                bytes: 49856,
                pk_bytes: 64,
                sk_bytes: 128,
                seed_bytes: 96,
            },
            ParameterSet::Sha2_256s => SphincsParams {
                n: 32,
                full_height: 64,
                d: 8,
                fors_height: 14,
                fors_trees: 22,
                wots_w: 16,
                addr_bytes: 32,
                wots_logw: 4,
                wots_len1: 64,
                wots_len2: 3,
                wots_len: 67,
                wots_bytes: 2144,
                wots_pk_bytes: 2144,
                tree_height: 8,
                fors_msg_bytes: 39,
                fors_bytes: 10560,
                fors_pk_bytes: 32,
                bytes: 29792,
                pk_bytes: 64,
                sk_bytes: 128,
                seed_bytes: 96,
            },
        }
    }

    /// Get the hash function type for this parameter set.
    pub fn hash_type(self) -> HashType {
        match self {
            ParameterSet::Shake128f
            | ParameterSet::Shake128s
            | ParameterSet::Shake192f
            | ParameterSet::Shake192s
            | ParameterSet::Shake256f
            | ParameterSet::Shake256s => HashType::Shake,
            ParameterSet::Sha2_128f
            | ParameterSet::Sha2_128s
            | ParameterSet::Sha2_192f
            | ParameterSet::Sha2_192s
            | ParameterSet::Sha2_256f
            | ParameterSet::Sha2_256s => HashType::Sha2,
        }
    }

    /// Validate that the given seed length is correct for this parameter set.
    pub fn validate_seed_length(self, seed_len: usize) -> Result<()> {
        let expected = self.params().seed_bytes;
        if seed_len == expected {
            Ok(())
        } else {
            Err(Error::InvalidSeedLength)
        }
    }

    /// Validate that the given public key length is correct for this parameter set.
    pub fn validate_pk_length(self, pk_len: usize) -> Result<()> {
        let expected = self.params().pk_bytes;
        if pk_len == expected {
            Ok(())
        } else {
            Err(Error::InvalidKeyLength)
        }
    }

    /// Validate that the given secret key length is correct for this parameter set.
    pub fn validate_sk_length(self, sk_len: usize) -> Result<()> {
        let expected = self.params().sk_bytes;
        if sk_len == expected {
            Ok(())
        } else {
            Err(Error::InvalidKeyLength)
        }
    }

    /// Validate that the given signature length is correct for this parameter set.
    pub fn validate_signature_length(self, sig_len: usize) -> Result<()> {
        let expected = self.params().bytes;
        if sig_len == expected {
            Ok(())
        } else {
            Err(Error::InvalidSignatureLength)
        }
    }
}

/// Hash function type used by a parameter set.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HashType {
    /// SHAKE-based hash functions
    Shake,
    /// SHA2-based hash functions
    Sha2,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parameter_validation() {
        let params = ParameterSet::Shake128f;
        let p = params.params();

        assert!(params.validate_seed_length(p.seed_bytes).is_ok());
        assert!(params.validate_seed_length(p.seed_bytes + 1).is_err());

        assert!(params.validate_pk_length(p.pk_bytes).is_ok());
        assert!(params.validate_pk_length(p.pk_bytes + 1).is_err());

        assert!(params.validate_sk_length(p.sk_bytes).is_ok());
        assert!(params.validate_sk_length(p.sk_bytes + 1).is_err());

        assert!(params.validate_signature_length(p.bytes).is_ok());
        assert!(params.validate_signature_length(p.bytes + 1).is_err());
    }

    #[test]
    fn test_hash_types() {
        assert_eq!(ParameterSet::Shake128f.hash_type(), HashType::Shake);
        assert_eq!(ParameterSet::Sha2_128f.hash_type(), HashType::Sha2);
    }
}

