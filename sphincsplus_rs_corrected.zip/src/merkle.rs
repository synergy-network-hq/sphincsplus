//! Merkle tree and hypertree structures for SPHINCS+.

use crate::address::{Address, addr_type};
use crate::context::SphincsContext;
use crate::hash::prf_addr;
use crate::thash::thash_merkle;
use alloc::vec::Vec;
use alloc::vec;

/// Computes the root of a Merkle tree given a leaf and its authentication path.
/// This corresponds to `compute_root` in the C reference.
pub fn compute_root(
    root: &mut [u8],
    leaf: &[u8],
    mut leaf_idx: u32,
    mut tree_height: u32,
    auth_path: &[u8],
    ctx: &SphincsContext,
    tree_addr: &Address,
) {
    let n = ctx.params.n;
    assert_eq!(root.len(), n);
    assert_eq!(leaf.len(), n);

    let mut node = Vec::from(leaf);

    for i in 0..tree_height {
        let sibling = &auth_path[(i * n)..(i + 1) * n];
        let mut current_addr = tree_addr.clone();
        current_addr.set_tree_height(i as u32);
        current_addr.set_tree_index(leaf_idx >> 1);

        if leaf_idx & 1 == 0 {
            // Current node is left child
            thash_merkle(&mut node, &node, sibling, ctx, &current_addr);
        } else {
            // Current node is right child
            thash_merkle(&mut node, sibling, &node, ctx, &current_addr);
        }
        leaf_idx >>= 1;
    }
    root.copy_from_slice(&node);
}

/// Generates a Merkle tree authentication path and the root.
/// This corresponds to `merkle_gen_root` and `merkle_sign` in the C reference.
pub fn merkle_gen_root(
    root: &mut [u8],
    sk_seed: &[u8],
    ctx: &SphincsContext,
    tree_addr: &Address,
) {
    let params = &ctx.params;
    let n = params.n;
    let tree_height = params.tree_height;
    let num_leaves = 1 << tree_height;

    let mut leaves = vec![0u8; num_leaves * n];

    // Generate all WOTS+ public keys (leaves of the Merkle tree)
    for i in 0..num_leaves {
        let mut wots_pk_addr = tree_addr.clone();
        wots_pk_addr.set_type(addr_type::WOTS_PK);
        wots_pk_addr.set_keypair(i as u32);
        
        let mut wots_pk = vec![0u8; params.wots_pk_bytes];
        crate::wots::wots_pk_gen(&mut wots_pk, sk_seed, ctx, &wots_pk_addr);
        
        // Hash the WOTS+ public key to get the Merkle tree leaf
        let mut leaf_addr = wots_pk_addr.clone();
        leaf_addr.set_type(addr_type::HASH_TREE);
        leaf_addr.set_tree_height(0);
        leaf_addr.set_tree_index(i as u32);
        crate::thash::thash(&mut leaves[i * n..(i + 1) * n], &wots_pk, params.wots_len, ctx, &leaf_addr);
    }

    // Compute the Merkle tree root
    let mut nodes = leaves;
    let mut current_level_size = num_leaves;

    for h in 0..tree_height {
        for i in 0..current_level_size / 2 {
            let left_child = &nodes[i * 2 * n..(i * 2 + 1) * n];
            let right_child = &nodes[(i * 2 + 1) * n..(i * 2 + 2) * n];

            let mut node_addr = tree_addr.clone();
            node_addr.set_tree_height((h + 1) as u32);
            node_addr.set_tree_index(i as u32);
            
            thash_merkle(&mut nodes[i * n..(i + 1) * n], left_child, right_child, ctx, &node_addr);
        }
        current_level_size /= 2;
    }
    root.copy_from_slice(&nodes[0..n]);
}

/// Generates a Merkle tree authentication path for a given leaf index.
/// This corresponds to `merkle_sign` in the C reference.
pub fn merkle_sign(
    auth_path: &mut [u8],
    leaf: &[u8],
    leaf_idx: u32,
    sk_seed: &[u8],
    ctx: &SphincsContext,
    tree_addr: &Address,
) {
    let params = &ctx.params;
    let n = params.n;
    let tree_height = params.tree_height;
    let num_leaves = 1 << tree_height;

    assert_eq!(auth_path.len(), tree_height * n);
    assert_eq!(leaf.len(), n);

    let mut leaves = vec![0u8; num_leaves * n];

    // Generate all WOTS+ public keys (leaves of the Merkle tree)
    for i in 0..num_leaves {
        let mut wots_pk_addr = tree_addr.clone();
        wots_pk_addr.set_type(addr_type::WOTS_PK);
        wots_pk_addr.set_keypair(i as u32);
        
        let mut wots_pk = vec![0u8; params.wots_pk_bytes];
        crate::wots::wots_pk_gen(&mut wots_pk, sk_seed, ctx, &wots_pk_addr);
        
        // Hash the WOTS+ public key to get the Merkle tree leaf
        let mut leaf_addr = wots_pk_addr.clone();
        leaf_addr.set_type(addr_type::HASH_TREE);
        leaf_addr.set_tree_height(0);
        leaf_addr.set_tree_index(i as u32);
        crate::thash::thash(&mut leaves[i * n..(i + 1) * n], &wots_pk, params.wots_len, ctx, &leaf_addr);
    }

    // Compute the authentication path
    let mut nodes = leaves;
    let mut current_level_size = num_leaves;

    for h in 0..tree_height {
        let sibling_idx = leaf_idx ^ 1;
        auth_path[h * n..(h + 1) * n].copy_from_slice(&nodes[sibling_idx as usize * n..(sibling_idx as usize + 1) * n]);

        for i in 0..current_level_size / 2 {
            let left_child = &nodes[i * 2 * n..(i * 2 + 1) * n];
            let right_child = &nodes[(i * 2 + 1) * n..(i * 2 + 2) * n];

            let mut node_addr = tree_addr.clone();
            node_addr.set_tree_height((h + 1) as u32);
            node_addr.set_tree_index(i as u32);
            
            thash_merkle(&mut nodes[i * n..(i + 1) * n], left_child, right_child, ctx, &node_addr);
        }
        current_level_size /= 2;
        leaf_idx >>= 1;
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params::ParameterSet;
    use crate::context::SphincsContext;
    use crate::wots;

    #[test]
    fn test_merkle_gen_root_and_compute_root() {
        let parameter_set = ParameterSet::Shake128f;
        let params = parameter_set.params();
        let sk_seed = vec![0x01; params.n];
        let mut ctx = SphincsContext::new_for_signing(parameter_set, &vec![0u8; params.n], &sk_seed);
        
        let mut tree_addr = Address::new();
        tree_addr.setup_hash_tree(0, 0);

        let mut root_gen = vec![0u8; params.n];
        merkle_gen_root(&mut root_gen, &sk_seed, &ctx, &tree_addr);

        // To test compute_root, we need a leaf and an authentication path.
        // Let's generate a specific leaf and its path.
        let leaf_idx = 0u32;
        let mut wots_pk_addr = tree_addr.clone();
        wots_pk_addr.set_type(addr_type::WOTS_PK);
        wots_pk_addr.set_keypair(leaf_idx);
        
        let mut wots_pk = vec![0u8; params.wots_pk_bytes];
        wots::wots_pk_gen(&mut wots_pk, &sk_seed, &ctx, &wots_pk_addr);
        
        let mut leaf = vec![0u8; params.n];
        let mut leaf_addr = wots_pk_addr.clone();
        leaf_addr.set_type(addr_type::HASH_TREE);
        leaf_addr.set_tree_height(0);
        leaf_addr.set_tree_index(leaf_idx);
        crate::thash::thash(&mut leaf, &wots_pk, params.wots_len, &ctx, &leaf_addr);

        let mut auth_path = vec![0u8; params.tree_height * params.n];
        merkle_sign(&mut auth_path, &leaf, leaf_idx, &sk_seed, &ctx, &tree_addr);

        let mut root_computed = vec![0u8; params.n];
        compute_root(&mut root_computed, &leaf, leaf_idx, params.tree_height as u32, &auth_path, &ctx, &tree_addr);

        assert_eq!(root_gen, root_computed);
    }
}

