//! Tweakable hash functions for SPHINCS+.
//!
//! This module implements the tweakable hash functions used in SPHINCS+,
//! which are parameterized by an address to provide domain separation.

use crate::address::Address;
use crate::context::SphincsContext;
use crate::params::HashType;
use alloc::vec::Vec;
use sha2::{Sha256, Digest};
use sha3::{Shake256, digest::{Update, ExtendableOutput, XofReader}};

/// Tweakable hash function that takes multiple inputs and produces one output.
/// This corresponds to `thash` in the C reference.
pub fn thash(
    out: &mut [u8],
    input: &[u8],
    inblocks: usize,
    ctx: &SphincsContext,
    addr: &Address,
) {
    let params = &ctx.params;
    let n = params.n;
    assert_eq!(out.len(), n);
    assert_eq!(input.len(), inblocks * n);

    match ctx.parameter_set.hash_type() {
        HashType::Shake => thash_shake(out, input, inblocks, ctx, addr),
        HashType::Sha2 => thash_sha2(out, input, inblocks, ctx, addr),
    }
}

/// SHAKE-based tweakable hash function.
fn thash_shake(
    out: &mut [u8],
    input: &[u8],
    inblocks: usize,
    ctx: &SphincsContext,
    addr: &Address,
) {
    let params = &ctx.params;
    let n = params.n;

    // Domain separator for SHAKE-based thash
    let mut buf = Vec::with_capacity(n + params.addr_bytes + input.len());
    buf.extend_from_slice(ctx.pub_seed());
    buf.extend_from_slice(&addr.to_byte_array());
    buf.extend_from_slice(input);

    let mut hasher = Shake256::default();
    Update::update(&mut hasher, &buf);
    hasher.finalize_xof().read(out);
}

/// SHA2-based tweakable hash function.
fn thash_sha2(
    out: &mut [u8],
    input: &[u8],
    inblocks: usize,
    ctx: &SphincsContext,
    addr: &Address,
) {
    let params = &ctx.params;
    let n = params.n;

    // For SHA2, we use a construction similar to the C reference
    let mut buf = Vec::with_capacity(n + params.addr_bytes + input.len());
    buf.extend_from_slice(ctx.pub_seed());
    buf.extend_from_slice(&addr.to_byte_array());
    buf.extend_from_slice(input);

    // Use SHA256 and truncate if necessary
    let mut hasher = Sha256::new();
    Digest::update(&mut hasher, &buf);
    let hash_result = hasher.finalize();
    
    if n <= 32 {
        out.copy_from_slice(&hash_result[0..n]);
    } else {
        // For larger n, we would need to use SHA512 or multiple rounds
        panic!("SHA2 thash with n > 32 not implemented");
    }
}

/// Tweakable hash function for WOTS+ chains.
/// This is a specialized version of thash for WOTS+ chain computations.
pub fn thash_wots(
    out: &mut [u8],
    input: &[u8],
    ctx: &SphincsContext,
    addr: &Address,
) {
    thash(out, input, 1, ctx, addr);
}

/// Tweakable hash function for Merkle tree nodes.
/// This is a specialized version of thash for Merkle tree computations.
pub fn thash_merkle(
    out: &mut [u8],
    left: &[u8],
    right: &[u8],
    ctx: &SphincsContext,
    addr: &Address,
) {
    let n = ctx.params.n;
    assert_eq!(left.len(), n);
    assert_eq!(right.len(), n);
    
    let mut input = Vec::with_capacity(2 * n);
    input.extend_from_slice(left);
    input.extend_from_slice(right);
    
    thash(out, &input, 2, ctx, addr);
}

/// Tweakable hash function for FORS trees.
/// This is a specialized version of thash for FORS tree computations.
pub fn thash_fors(
    out: &mut [u8],
    input: &[u8],
    ctx: &SphincsContext,
    addr: &Address,
) {
    thash(out, input, 1, ctx, addr);
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::params::ParameterSet;

    #[test]
    fn test_thash_basic() {
        let parameter_set = ParameterSet::Shake128f;
        let params = parameter_set.params();
        let ctx = SphincsContext::new_for_verification(parameter_set, &vec![0u8; params.n]);
        
        let input = vec![0x01; params.n];
        let mut addr = Address::new();
        addr.set_type(1);
        addr.set_keypair(2);

        let mut out = vec![0u8; params.n];
        thash(&mut out, &input, 1, &ctx, &addr);
        
        // Output should not be all zeros for non-zero input
        assert!(!out.iter().all(|&x| x == 0));
    }

    #[test]
    fn test_thash_merkle() {
        let parameter_set = ParameterSet::Shake128f;
        let params = parameter_set.params();
        let ctx = SphincsContext::new_for_verification(parameter_set, &vec![0u8; params.n]);
        
        let left = vec![0x02; params.n];
        let right = vec![0x03; params.n];
        let mut addr = Address::new();
        addr.set_type(2);

        let mut out = vec![0u8; params.n];
        thash_merkle(&mut out, &left, &right, &ctx, &addr);
        
        assert!(!out.iter().all(|&x| x == 0));
    }

    #[test]
    fn test_thash_deterministic() {
        let parameter_set = ParameterSet::Shake128f;
        let params = parameter_set.params();
        let ctx = SphincsContext::new_for_verification(parameter_set, &vec![0u8; params.n]);
        
        let input = vec![0x04; params.n];
        let mut addr = Address::new();
        addr.set_type(3);

        let mut out1 = vec![0u8; params.n];
        let mut out2 = vec![0u8; params.n];
        
        thash(&mut out1, &input, 1, &ctx, &addr);
        thash(&mut out2, &input, 1, &ctx, &addr);
        
        // Same input should produce same output
        assert_eq!(out1, out2);
    }

    #[test]
    fn test_thash_different_addresses() {
        let parameter_set = ParameterSet::Shake128f;
        let params = parameter_set.params();
        let ctx = SphincsContext::new_for_verification(parameter_set, &vec![0u8; params.n]);
        
        let input = vec![0x05; params.n];
        let mut addr1 = Address::new();
        addr1.set_type(1);
        let mut addr2 = Address::new();
        addr2.set_type(2);

        let mut out1 = vec![0u8; params.n];
        let mut out2 = vec![0u8; params.n];
        
        thash(&mut out1, &input, 1, &ctx, &addr1);
        thash(&mut out2, &input, 1, &ctx, &addr2);
        
        // Different addresses should produce different outputs
        assert_ne!(out1, out2);
    }
}

